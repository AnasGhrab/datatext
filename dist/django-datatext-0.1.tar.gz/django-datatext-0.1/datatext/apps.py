from django.apps import AppConfig

class DataTextConfig(AppConfig):
    name = 'datatext'
    verbose_name = "DaTaText"