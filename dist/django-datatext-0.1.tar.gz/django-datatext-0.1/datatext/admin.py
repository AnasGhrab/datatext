from django.contrib import admin
from .models import *

admin.site.register(Auteur)
admin.site.register(Texte)
admin.site.register(Copie)
admin.site.register(Section)
admin.site.register(Categorie)
admin.site.register(Corpus)
admin.site.register(Bibliotheque)